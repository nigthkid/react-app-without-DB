export const tasks = [
    {
        id: 0,
        title: "mi primer tarea",
        description: "mi primer tarea",
    },
    {
        id: 1,
        title: "mi segunda tarea",
        description: "mi segunda tarea",
    },
    {
        id: 2,
        title: "mi tercera tarea",
        description: "mi tercera tarea",
    },
];